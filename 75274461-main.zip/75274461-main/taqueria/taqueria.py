def main():


    menu = {
    "Baja Taco": 4.00,
    "Burrito": 7.50,
    "Bowl": 8.50,
    "Nachos": 11.00,
    "Quesadilla": 8.50,
    "Super Burrito": 8.50,
    "Super Quesadilla": 9.50,
    "Taco": 3.00,
    "Tortilla Salad": 8.00
}
    Display_Cost(menu)



def Display_Cost(menu):
    n = 0
    try:
          while True:
            item = input("item: ")
            item = item.title()
            if item in menu:
                cost = menu.get(item)
                n += cost
                print(f"Total: ${n:.2f}")

    except EOFError:
        pass
    print(end = "\n")




main()