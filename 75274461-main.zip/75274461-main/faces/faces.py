def main():
    convert()

def convert():
    faces = input()
    new_faces = faces.replace(':)','🙂').replace(':(','🙁')
    print(new_faces)



main()
