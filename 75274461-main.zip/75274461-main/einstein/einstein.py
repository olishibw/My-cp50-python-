def main():
    einstein()

def einstein():
    Mass = int(input("M: "))
    Energy = Mass*pow(300000000,2)
    print(f"E: {Energy}")

main()