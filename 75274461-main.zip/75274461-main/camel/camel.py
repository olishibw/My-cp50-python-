def main():
    name = input("camelCase: ")
    camelCase(name)

    print(f"snake_case: {camelCase(name)}")

def camelCase(name):
    snake_case = ""
    for i in name:
        if i.isupper():
          snake_case += "_" + i.lower()
        else:
            snake_case += i
    return snake_case


main()