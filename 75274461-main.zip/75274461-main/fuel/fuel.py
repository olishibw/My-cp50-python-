def main():
    t = get_fraciton()
    print(t)

def get_fraciton():
    while True:
        try:
            fraction = input("Fraction: ")
            x,z = fraction.split("/")
            x = int(x)
            z = int(z)
            if x <= z:
                w = int(round(x/z,2) * 100 )
                if w <= 1:
                    w = "E"
                    return w
                elif w >= 99 and w <= 100 :
                    w = "F"
                    return w
                else:
                    w = f"{w}%"
                    return w

        except (ValueError, ZeroDivisionError):
                pass




main()

