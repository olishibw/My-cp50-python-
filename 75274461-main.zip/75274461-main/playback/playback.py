playback = input()
playback1 = playback.replace(' ', '...')
print(playback1)