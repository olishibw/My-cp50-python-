from bank import value


def test_hello():
    assert value("hello") == 0
def test_startwith_hello():
    assert value("hello,world") == 0
def test_h():
    assert value ("HaweTen") == 20
def test_else():
    assert value ("girma|") == 100

