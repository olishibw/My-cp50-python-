def main():
    greeting = input("Greeting: ")
    award = value(greeting)
    print(f"${award}")

def value(greeting):
    greeting = greeting.replace(" ","")
    greeting = greeting.lower()
    if greeting.startswith("hello") or greeting == "hello":
        return 0
    elif greeting != "hello" and greeting.startswith("h") :
       return 20
    else:
        return 100



if __name__ == "__main__":
    main()











