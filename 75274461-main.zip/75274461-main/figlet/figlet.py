import sys
from pyfiglet import Figlet

figlet = Figlet()
try:
  if len(sys.argv) > 4 and len(sys.argv) != 1 or sys.argv[2] not in figlet.getFonts() or sys.argv[1] != "-f" and sys.argv[1] != "--font":
    sys.exit("Invalid usage")
  elif len(sys.argv) == 1:
    figlet.setFont()
    Font = input("Input: ")
    print(f"Output: \n{figlet.renderText(Font)}")
  else:
    figlet.setFont(font = sys.argv[2])
    Font = input("Input: ")
    print(f"Output: \n{figlet.renderText(Font)}")
except IndexError:
   sys.exit("Invalid usage")





