def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(plate):
        if len(plate) < 7 and len(plate) > 3 and plate[0].isalpha() and plate[1].isalpha()  and plate[2] != "0" and plate.isalnum():
             return check(plate)
        else:
            return False


def check(plate):

    if plate.isalpha():
            return True
    elif plate[2:5].isdigit() and plate[-1:-4].isalpha():

            return False
    elif plate[2:3].isdigit() and plate[4:5].isalpha():
        return False
    return True











if __name__ == "__main__":
    main()
