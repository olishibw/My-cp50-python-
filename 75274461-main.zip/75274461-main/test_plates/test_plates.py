import plates

def test_valid():
    assert plates.is_valid("CS50") == True
    assert plates.is_valid("HAWE") == True
    assert plates.is_valid("HA") == True

def test_invalid():
    assert plates.is_valid("CS05") == False
    assert plates.is_valid("50cs") == False
    assert plates.is_valid("CS50P") == False
    assert plates.is_valid("PI3.14") == False
    assert plates.is_valid("H7") == False
    assert plates.is_valid("H") == False
    assert plates.is_valid("OUTATIME") == False
    assert plates.is_valid("HELLO, WORLD") == False

