"""greeting = input("Greeting: ")
greeting = greeting.replace(" ","")
greeting = greeting.lower()


if greeting.startswith("hello") or greeting == "hello":
    print("$0")
elif greeting != "hello" and greeting.startswith("h") :
   print("$20")
else:
    print("$100")"""

def main():
    greeting = input("Greeting: ")
    print(value(greeting))

def value(greeting):
    greeting = greeting.replace(" ","")
    greeting = greeting.lower()
    if greeting.startswith("hello") or greeting == "hello":
        return "$0"
    elif greeting != "hello" and greeting.startswith("h") :
       return "$20"
    else:
        return "$100"


if __name__ == "__main__":
    main()





