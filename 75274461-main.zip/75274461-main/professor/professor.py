import random


def main():
    levels = get_level()
    correct = generate_integer(levels)

    print(f"Score: {correct}")


def get_level():
    level = [1,2,3]

    for i in range(1,3):
        try:
            levels = int(input("Level: "))
            if levels in level:
                return levels
        except ValueError:
            pass


def generate_integer(level):
    if level == 1:
        correct = 0
        for i in range(10):

            x ,y= random.randint(0,9),random.randint(0,9)
            addition = x + y

            for attempt in range(3):
                    try:
                        result = int(input(f"{x} + {y} = "))

                        if result == addition:
                            correct+=1
                            break
                        else:
                            print("EEE")
                            continue
                    except (ValueError):
                        print("EEE")
                        pass
            if result != addition:
                    print(f"{x} + {y} = {addition}")

        return correct
    elif level == 2:
        correct = 0
        for i in range(10):
            x ,y= random.randint(10,99),random.randint(10,99)
            addition = x + y
            for attempt in range(3):
                    try:
                        result = int(input(f"{x} + {y} = "))

                        if result == addition:
                            correct+=1
                            break
                        else:
                            print("EEE")
                            continue
                    except (ValueError):
                        print("EEE")
                        pass
            if result != addition:
                    print(f"{x} + {y} = {addition}")
        return correct
    else:
        correct = 0
        for i in range(10):

                x ,y= random.randint(100,999),random.randint(100,999)
                addition = x + y
                for attempt in range(3):
                    try:
                        result = int(input(f"{x} + {y} = "))

                        if result == addition:
                            correct+=1
                            break
                        else:
                            print("EEE")
                            continue
                    except (ValueError):
                        print("EEE")
                        pass
                if result != addition:
                    print(f"{x} + {y} = {addition}")

        return correct



if __name__ == "__main__":
    main()