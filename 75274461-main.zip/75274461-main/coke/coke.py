
number = 50
numbers = [5,10,25]



while number != 0:
        print("Amount Due:",number)
        user_input = int(input("Insert Coin: "))
        if user_input in numbers :
            number -= user_input
            if number <= 0:
                break
print("Change Owed:",-1*number)


















