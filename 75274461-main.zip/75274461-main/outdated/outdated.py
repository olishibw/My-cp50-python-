def main():
    month= [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]
    months= {
    "January":1,
    "February":2,
    "March":3,
    "April":4,
    "May":5,
    "June":6,
    "July":7,
    "August":8,
    "September":9,
    "October":10,
    "November":11,
    "December":12
}

    values=changes(month,months)

    print(values)



def changes(month,months):
    while True:
        try:

                value = input("Date: ")
                if "/" in value:
                    x,y,z = value.split("/")
                    if x not in month:
                        x= int(x)
                        y= int(y)
                        z= int(z)
                        if y <= 31 and x <= 12:
                            values = f"{z}-{x:02}-{y:02}"
                            return values

                elif "," in value:
                        mon,da,yea = value.split(" ")
                        da = da.replace(",","")
                        da = int(da)
                        yea = int(yea)
                        if mon in month and da <= 31:
                            mon = months[mon]
                            if mon is None:
                                return False
                            else:
                                values = f"{yea}-{mon:02}-{da:02}"
                                return values


        except :
            pass



main()