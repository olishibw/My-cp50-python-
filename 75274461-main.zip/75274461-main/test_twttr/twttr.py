def main():
    twttr = input(" input")
    print(shorten(twttr))



def shorten(word):
    vowels = ["a","e","i","o","u","A","E","I","O","U"]
    non_vowels = [i for i in word if i not in vowels]
    twttr = ''.join(non_vowels)
    return twttr


if __name__ == "__main__":
    main()


