from twttr import shorten

def test_lowerword():
    assert shorten("Twitter") == "Twttr"
def test_capitalword():
    assert shorten("HGO") == "HG"
def test_sentences():
    assert shorten("What's your name?") == "Wht's yr nm?"
def test_word_number():
    assert shorten("cs50") == "cs50"
