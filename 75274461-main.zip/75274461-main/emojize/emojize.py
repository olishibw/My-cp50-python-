import emoji
emoj = input("Input: ")
emojie = emoji.emojize("Output: " + emoj)
print(emojie)