print("what's is the Answer to the Great Question of Life, the universe, and Everything?",end=' ')
deep = input()
deep = deep.lower()
deep = deep.replace(" ","")

match deep:
    case "42" | "fortytwo" | "forty-two" :
        print("Yes")
    case _:
        print("No")