#def main():


    #twttr = input("Input: ")
    #is_vowel(twttr)

    #non_vowels=[char for char in twttr  if not is_vowel(char)]
    #new_string = "".join(non_vowels)
    #print(f"Output: {new_string}")
#def is_vowel(twttr):
  #  vowels = ["a","e","i","o","u","A","E","I","O","U"]
   # for i in twttr:
        #if i in vowels:

            #return True

#main()

def main():
    twttr = input(" input")
    print(shorten(twttr))



def shorten(word):
    vowels = ["a","e","i","o","u","A","E","I","O","U"]
    non_vowels = [i for i in word if i not in vowels]
    twttr = ''.join(non_vowels)
    return twttr


if __name__ == "__main__":
    main()
