def main():


   cap()
def cap():
    grocery = {}
    counts = {}
    try:
      for i in range(1,1000):
         value = input()
         grocery[i] = value
         if value in counts:
            counts[value] += 1
         else:
            counts[value] = 1
    except EOFError:
      pass
    for value in sorted(counts):
       print(counts[value] , value.upper())










main()