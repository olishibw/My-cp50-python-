def main():
    fraction = input("Fraction: ")
    t = convert(fraction)
    r = gauge(t)
    print(r)

def convert(fraction):
    while True:
        try:
            x,z = fraction.split("/")
            x = int(x)
            z = int(z)
            if x <= z:
                w = int(round(x/z,2) * 100 )
                return w

        except (ValueError, ZeroDivisionError):
                pass

def gauge(t):
        if t <= 1:
            t = "E"
            return t
        elif t >= 99 and t <= 100 :
            t = "F"
            return t
        else:
            t= f"{t}%"
            return t

if __name__ == "__main__":
    main()