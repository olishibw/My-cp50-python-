import inflect

adieu = inflect.engine()
name_list = []
try:
   while True:
    name = input("Name: ")
    name_list.append(name)

except EOFError:
   pass

name = adieu.join(name_list)
print(f"\nAdieu, adieu, to {name}")
