import random


while True:
                try:
                 level = int(input("Level: "))
                 integer = random.randint(1,level)
                 if level < 0:
                         continue
                except(ValueError, NameError):
                        pass
                        continue
                while True:

                        try:
                                guess = int(input("Guess: "))
                                if guess < 0:
                                        continue
                        except (ValueError , NameError):
                                pass
                                continue



                        if guess == integer:
                                print("Just right!")
                                break
                        elif guess < integer:
                                print("Too small!")

                        elif guess > integer:
                                print("Too large!")
                break














