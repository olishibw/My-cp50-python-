import json
import requests
import sys

try:
    if len(sys.argv) != 2:
        sys.exit("Missing command-line argument")
    elif float(sys.argv[1]):
        pass
    elif not sys.argv[1].isdigit():
        sys.exit("Command-line argument is not a number")
except requests.RequestException:
    pass
respose = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
obj = respose.json()
rate = obj["bpi"]["USD"]["rate"]
rate = rate.replace(",","")
rate = float(rate)
exchange = rate * float(sys.argv[1])
print(f"${exchange:,.4f}")
