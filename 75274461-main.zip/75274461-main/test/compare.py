#def main():
#    x = int(input("what's is x? "))
 #   if is_odd(x):
 #       print("odd")
 #   else:
  #      print("even")

#def is_odd(n):
 #   return n % 2 != 0
#main()
#twttr = input(" input")
##non_vowels = [i for i in twttr if i not in vowels]
#twttr = ''.join(non_vowels)
#print(twttr)


"""def check_string(string):
    if len(string) >= 7 or not string[0].isalpha() or not string[1].isalpha() or string[2] == '0':
        print("Invalid")
    elif string[-1].isalpha() and any(char.isdigit() for char in string[1:-1]):
        print("Invalid")
    elif not string.isalnum():
        print("Invalid")
    else:
        print("Valid")

test_string = input("Enter a string: ")
check_string(test_string)
"""
month= [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]
months= {
    "January":1,
    "February":2,
    "March":3,
    "April":4,
    "May":5,
    "June":6,
    "July":7,
    "August":8,
    "September":9,
    "October":10,
    "November":11,
    "December":12
}
while True:
    try:

        value = input()
        mon,da,yea = value.split(" ")
        da = da.replace(",","")
        da = int(da)
        yea = int(yea)
        if mon in month and da <= 31:
            mon = months[mon]
            if mon is None:
                print("none")
            else:
                values = f"{yea}-{mon:02}-{da:02}"
                print (values)
    except:
        pass